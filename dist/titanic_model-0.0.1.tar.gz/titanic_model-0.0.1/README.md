# Survivability-for-the-Titanic
Predict Survivability for the Titanic Dataset using Modular Approach -- Assignment 1 Module 3


